<?php $__env->startSection('title', 'Home | AEAP'); ?>


<?php $__env->startSection('content'); ?>


    <?php echo $__env->make('banner-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    <div class="welder-service-section section-margin-top each-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="service-welder-left">
                        <img src="<?php echo e(asset('/assets/images/service-left.png')); ?>" alt="welder service">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="service-right pl-5">
                        <div class="section-heading">
                            <h2 class="text-left">In-house & on-site welder services</h2>
                        </div>
                        <div class="para-text">
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt eos illo laudantium omnis. A, commodi dolor expedita
                                fugit inventore iste modi nemo odio quae qui, reprehenderit soluta tenetur. At cumque distinctio earum laboriosam minima
                                molestias mollitia pariatur perferendis, possimus voluptates! Adipisci in nam quia sequi sit. Dolore eius facere nesciunt.
                            </p>
                        </div>
                        <ul class="list-style-cm">
                            <li>Welding and Cutting</li>
                            <li>Fabrication and Engineering</li>
                            <li>Coded Welding</li>
                            <li>Hydrostatic Testing</li>
                            <li>Basic Machining</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>


<!--    <div class="get-work-section section-margin-top each-section">
        <div class="container">
            <div class="section-heading">
                <h2>Brands</h2>
            </div>
            <div class="row" style="background: #1a1a1a; padding: 28px 14px;  border-radius: 12px;">
                <div class="col-md-2 mt-4">
                    <div class="each-brands">
                        <img src="<?php echo e(asset('/assets/images/brands/b1.png')); ?>" alt="brand images">
                    </div>
                </div>
                <div class="col-md-2 mt-4">
                    <div class="each-brands">
                        <img src="<?php echo e(asset('/assets/images/brands/b2.png')); ?>" alt="brand images">
                    </div>
                </div>
                <div class="col-md-2 mt-4">
                    <div class="each-brands">
                        <img src="<?php echo e(asset('/assets/images/brands/b3.png')); ?>" alt="brand images">
                    </div>
                </div>
                <div class="col-md-2 mt-4">
                    <div class="each-brands">
                        <img src="<?php echo e(asset('/assets/images/brands/b4.png')); ?>" alt="brand images">
                    </div>
                </div>
                <div class="col-md-2 mt-4">
                    <div class="each-brands">
                        <img src="<?php echo e(asset('/assets/images/brands/b5.png')); ?>" alt="brand images">
                    </div>
                </div>
                <div class="col-md-2 mt-4">
                    <div class="each-brands">
                        <img src="<?php echo e(asset('/assets/images/brands/b6.png')); ?>" alt="brand images">
                    </div>
                </div>
                <div class="col-md-2 mt-4">
                    <div class="each-brands">
                        <img src="<?php echo e(asset('/assets/images/brands/b7.png')); ?>" alt="brand images">
                    </div>
                </div>
                <div class="col-md-2 mt-4">
                    <div class="each-brands">
                        <img src="<?php echo e(asset('/assets/images/brands/b8.png')); ?>" alt="brand images">
                    </div>
                </div>
                <div class="col-md-2 mt-4">
                    <div class="each-brands">
                        <img src="<?php echo e(asset('/assets/images/brands/b9.png')); ?>" alt="brand images">
                    </div>
                </div>
                <div class="col-md-2 mt-4">
                    <div class="each-brands">
                        <img src="<?php echo e(asset('/assets/images/brands/b10.png')); ?>" alt="brand images">
                    </div>
                </div>
            </div>
        </div>
    </div>-->



    
    



    

    <div class="about-us-section section-margin-top each-section">
        <div class="container">
            <div class="section-heading">
                <h2>About us</h2>
            </div>
        </div>
        <div class="about-container">
            <div class="hero">
                <div class="left">
                    <div class="section-heading">
                        <h2 class="text-left" style="color: black">American equipment<br><span style="color: #eab902"><b>and parts</b></span></h2>
                    </div>
                    <div class="para-text">
                        <p style="color: #000000">
                            American Equipment & parts is committed to serving the mining and construction industries with new, rebuilt, and quality
                            used replacement parts for off-highway heavy mobile equipment such as haul trucks, electric and hydraulic shovels, drills, loaders,
                            dozers, and much more. We have access to a growing inventory of diesel engines, transmissions, suspensions, hydraulic cylinders, final
                            drive parts, gears, differentials, electric motors, plus the smaller, harder to find parts you may need.
                        </p>
                    </div>
                </div>
                <div class="right">
                    <img src="<?php echo e(asset('/assets/images/about-02.jpg')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cosmics1/aep.cosmicsofts.com/resources/views/pages/index.blade.php ENDPATH**/ ?>