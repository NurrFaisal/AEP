<!--TOP NAVIGATION-->
<header id="header">
    <div class="topnav" id="myTopnav">
        <a href="/"><img class="logo" style="width:150px" src="<?php echo e(URL::to('/assets/images/aep-logo2.png')); ?>" alt=""></a>
        
        <a style="font-weight: 600; font-size: 17px" href="<?php echo e(route('home')); ?>">Home</a>
        
        <a style="font-weight: 600; font-size: 17px" href="<?php echo e(route('brand')); ?>">Brands</a>
        <a style="font-weight: 600; font-size: 17px" href="<?php echo e(route('about')); ?>">Who we are</a>
        <a style="font-weight: 600; font-size: 17px" href="<?php echo e(route('contact')); ?>">Contact</a>


        <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="NavBar()">&#9776;</a>
    </div>
</header>

<script>
    //TOP NAVIGATION
    function NavBar() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
            x.className += " responsive";
        } else {
            x.className = "topnav";
        }
    }
    window.onscroll = function() {scrollFunction()};
    function scrollFunction() {
        if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
            document.getElementById("myTopnav").style.width = "100%";
            document.getElementById("myTopnav").style.backgroundColor = "rgba(6, 18, 33, 1)";
            document.getElementById("header").style.position = "fixed";
            document.getElementById("header").style.top = "0%";
        } else {
            document.getElementById("myTopnav").style.width = "80%";
            document.getElementById("myTopnav").style.backgroundColor = "rgba(6, 18, 33, 0.8)";
            document.getElementById("header").style.position = "fixed";
            document.getElementById("header").style.top = "2rem";
        }
    }


</script>
<?php /**PATH F:\Projects\php\laravel\AEAP\resources\views/layouts/header.blade.php ENDPATH**/ ?>